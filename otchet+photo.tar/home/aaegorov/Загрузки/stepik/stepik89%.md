# Внешний курс STEPIK

## Выполнение работы
### 1 раздел

![Коментарий](1.1.png)
![Коментарий](Screenshot_2.png)
![Коментарий](Screenshot_3.png)
![Коментарий](Screenshot_4.png)
![Коментарий](Screenshot_5.png)
![Коментарий](Screenshot_6.png)
![Коментарий](Screenshot_7.png)
![Коментарий](Screenshot_8.png)
![Коментарий](Screenshot_9_1.4.png)

![Коментарий](Screenshot_10.png)
![Коментарий](Screenshot_11.png)
![Коментарий](Screenshot_12.png)
![Коментарий](Screenshot_13.png)
![Коментарий](Screenshot_14_1.5.png)
![Коментарий](Screenshot_15.png)
![Коментарий](Screenshot_16_1.6.png)
![Коментарий](Screenshot_17.png)
![Коментарий](Screenshot_18.png)
![Коментарий](Screenshot_19_1.7.png)
![Коментарий](Screenshot_20.png)
![Коментарий](Screenshot_21.png)
![Коментарий](Screenshot_22_1.8.png)
![Коментарий](Screenshot_23.png)
![Коментарий](Screenshot_24.png)
![Коментарий](Screenshot_25_1.9.png)
![Коментарий](Screenshot_26.png)
![Коментарий](Screenshot_27_1.9.png)
### 2 раздел
![Коментарий](Screenshot_28.png)

![Коментарий](Screenshot_29_2.2.png)

![Коментарий](Screenshot_30.png)

![Коментарий](Screenshot_31_2.3.png)

![Коментарий](Screenshot_32.png)

![Коментарий](Screenshot_33.png)

![Коментарий](Screenshot_34.png)

![Коментарий](Screenshot_35_2.4.png)

![Коментарий](Screenshot_36.png)

![Коментарий](Screenshot_37.png)

![Коментарий](Screenshot_38.png)

![Коментарий](Screenshot_39_2.5.png)

![Коментарий](Screenshot_40.png)
![Коментарий](Screenshot_41.png)
![Коментарий](Screenshot_42.png)
![Коментарий](Screenshot_43.png)
![Коментарий](Screenshot_44_2.6.png)
![Коментарий](Screenshot_45.png)
![Коментарий](Screenshot_46.png)
![Коментарий](Screenshot_47.png)
![Коментарий](Screenshot_48.png)
![Коментарий](Screenshot_49.png)


### 3 раздел
![Коментарий](Screenshot_50_3.1.png)
![Коментарий](Screenshot_51.png)
![Коментарий](Screenshot_52.png)
![Коментарий](Screenshot_53_3.2.png)
![Коментарий](Screenshot_54.png)
![Коментарий](Screenshot_55.png)
![Коментарий](Screenshot_56_3.3.png)
![Коментарий](Screenshot_57.png)
![Коментарий](Screenshot_58_3.4.png)
![Коментарий](Screenshot_59.png)
![Коментарий](Screenshot_60.png)
![Коментарий](Screenshot_61_3.5.png)
![Коментарий](Screenshot_62.png)
![Коментарий](Screenshot_63.png)
![Коментарий](Screenshot_64.png)
![Коментарий](Screenshot_65.png)
![Коментарий](Screenshot_66_3.6.png)
![Коментарий](Screenshot_67.png)
![Коментарий](Screenshot_67.png)
![Коментарий](Screenshot_68.png)
![Коментарий](Screenshot_69.png)
![Коментарий](Screenshot_70_3.7.png)
![Коментарий](Screenshot_71.png)
![Коментарий](Screenshot_72.png)
![Коментарий](Screenshot_73.png)
# Какие были проблемы? 
1. На самом курсе есть задания которые вополняются в терминале. Их было невозможно выполнить так как терминал то не запускался, то выдавал ошибки при самых обычных действиях.(Временный сбой разрешении имён.)
![Коментарий](problem1.png)
2. Была проблема с ответами на задания. То есть я мог на какое-нибудь задание выбрать ответ и он сразу засчитывается, а на другом задание я мог до 7 раз тыкать на один ответ и он только потом засчитывался.

# Из-за этих проблем не смог пройти степик на 100%

Вот ссылка на сертификат: https://stepik.org/cert/2090630


![Коментарий](sertificat.png)


 

